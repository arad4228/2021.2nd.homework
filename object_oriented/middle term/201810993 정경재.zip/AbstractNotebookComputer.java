public abstract class AbstractNotebookComputer {
    public abstract double requiredSpace();
}
