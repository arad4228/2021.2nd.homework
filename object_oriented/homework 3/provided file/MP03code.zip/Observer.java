public interface Observer {
    void updateText(String s);
}
