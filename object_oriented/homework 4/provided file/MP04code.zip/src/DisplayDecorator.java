import javax.swing.*;

public abstract class DisplayDecorator extends Display {
    DisplayDecorator(int width, int height) {
        super(width, height);
    }
}

